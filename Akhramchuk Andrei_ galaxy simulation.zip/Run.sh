#!/bin/bash
java -cp ./bin Galaxy_SP2022 $@
